<html>
<head>
</head>
<body>
<center>
<h2> Parroquia San Ignacio de Loyola </h2>
<h3> Ficha del Representante</h3>
</center>

<form name="formulario6" method="post" action="conexion.php">
<center>
<table>
<tr>
<th align="left">Nombre del apadrinado </th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>
<tr>
<th align="left">Sacramento </th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>


<tr> <th>Padrinos y Madrinas </th> </tr>
<tr>
<th align="left">Nombres: </th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos: </th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombre: </th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>

<tr>
<th align="left">Apellidos</th> <th><input type="text" name="apellidoinstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombres: </th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos: </th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombre: </th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>

<tr>
<th align="left">Apellidos</th> <th><input type="text" name="apellidoinstructor" value=""></th>
</tr>

<tr>
<br>
<tr>
<tr>
<th><input type="submit" name="Aceptar" value="Aceptar"/> </th>
<th><input type="reset" name="Cancelar" value="Cancelar"/></th>
</tr>


</table>
</center>

</form> 

</body>
</html>
