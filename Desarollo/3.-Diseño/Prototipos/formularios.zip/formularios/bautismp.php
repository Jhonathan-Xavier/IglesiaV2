<html>
<head>
</head>
<body>
<center>
<h2> Parroquia San Ignacio de Loyola </h2>
<h3> Ficha Bautismo</h3>
</center>

<form name="formulario3" method="post" action="conexion.php">
<center>
<table>

<tr>
<th align="left">No:</th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>
<tr>
<th align="left" > Fecha del curso </th> 
<th align="left" >  <input type="date" name="nacimientoinstructor" id="nacimientoinstructor" > 
</th> 
<tr>
<th align="left" >  Fecha del Bustismo</th> 
<th align="left" >  <input type="date" name="nacimientoinstructor" id="nacimientoinstructor" > 
</th> 
<tr>
<th align="left" > Hora </th> 
<th align="left" >  <input type="date" name="nacimientoinstructor" id="nacimientoinstructor" > 

</tr>
<tr>
<th align="left">Nombre del bautizado:</th> <th><input type="text" name="apellidoinstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos del bautizado</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombres del padre</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos del padre</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombres de la madre</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos de la madre</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left" > Teléfono </th> 
<th align="left" style="width:50px">  <input name="telefonoinstructor" type="text" id="telefonoinstructor" > </th>                       
<th>  Celular <input type="text" name="celularinstructor" id="celularinstructor" > 
</th>                       
</tr>
<tr>
<br>
<tr>
<tr>
<th><input type="submit" name="Aceptar" value="Aceptar"/> </th>
<th><input type="reset" name="Cancelar" value="Cancelar"/></th>
</tr>

</table>
</center>

</table>
</center>

</form> 

</body>
</html>
