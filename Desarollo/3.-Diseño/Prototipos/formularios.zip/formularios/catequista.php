<html>
<head>
<title> Parroquia san Ignacio </title>
</head>

<body>
<aside>
	<img src="img/logo.jpeg" width="200px"> 

</aside>
<header>
<center>
<h2> Parroquia San Ignacio de Loyola </h2>
<h3> Ficha del Catequista </h3>
<br>
</center>
</header>
<form name="Catequista" id="cate_formulario"  method="post">
<center>
<table>
<tr>
<th style= "width:200px" align="left"> Nombres </th> 
<th>  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" placeholder="(Ej. Jhonathan Xavier) " id="nombre_catequista" name="nombre_catequista"> </th>                       
</tr>

<tr>
<th style= "width:110px" align="left" > Apellidos </th> 
<th>  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" placeholder="(Ej Pizarra)" id="apellidos_catequista" name="apellido catequista"> </th>                       
</tr>

<tr>
<th style= "width:200px" align="left"> C.I </th> 
<th>  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="cedula_catequista"
name="cedula_catequista"> </th>                       
</tr>

<tr>
<th style= "width:200px" align="left" > Fecha de nacimiento </th> 
<th align="left" >  <input type="date" id="nacimiento_catequista" name="trip-start" value="2020-07-19" min="2000-01-01" > </th>                       
</tr>
<tr>
<th align="left" > Nivel </th>
<th align="left"> <select name="nivel_catequista"> 
<option value="1"> Bautismo </option>
<option value="2">Primero de comunión</option>
<option value="3">Segundo de comunión</option>
<option value="4">Primero de confirmación</option>
<option value="5">Segundo de comunión</option>
<option value="6">Catequesis especial</option>
</select>
</tr>
<tr>
<th align="left"> Dirección domiciliara </th>
<th colspan="2" > <input type="text" id="direc_catequista" name="direc_catequista" size="53">
</tr>
<tr>
<th style= "width:200px" align="left" > Teléfono </th> 
<th align="left" style="width:50px">  <input type="text" id="telefono_catequista" name="telefono_catequista"> </th>                       
<th>  Celular <input type="text" id="celula_catequista" name="celula_catequista"> </th>                       
</tr>
<tr>
<th style= "width:200px" align="left"> Correo electrónico </th> 
<th>  <input type="text" nam="correo_catequista" name="correo_catequista"> </th>                       
</tr>
<tr>
<th style= "width:200px" align="left"> Facebook </th> 
<th>  <input type="text" nam="facebook_catequista" name="facebook_catequista"> </th>                       
</tr>
<tr>
<th style= "width:200px" align="left"> Estado Civil </th> 
<th style= "width:50px" align="left">  <select name="estado_ci_catequista" > 
<option  > Casado </option> 
<option  > Divorciado </option> 
<option  >  Soltero </option> 
<option  > Viudo </option> 
</select>
</th>     
</tr>
<tr>
<th style= "width:200px" align="left"> Profesión  </th> 
<th>  <input type="text" nam="prof_catequista" name="prof_catequista"> </th>                       
</tr>
<tr>
<th style= "width:200px" align="left"> Alergías  </th> 
<th>  <input type="text" nam="alerg_catequista" name="alerg_catequista"> </th>                       
</tr>

<tr>
<th style= "width.200px" align="left"> Tipo de Sangre </th> 
<th>  <input type="text" nam="tiposangre_catequista" name="tiposangre_catequista"> </th>                       
</tr>

<tr>
<th style= "width.200px" align="left"> Catequiste desde </th> 
<th>  <input type="date" nam="fechaingreso_catequista" name="tiposangre_catequista" value="2020-07-19" min="2000-01-01"> </th>                       
</tr>

</table>
</center>
</form>
       
</body>

</html>
