<html>
<head>
</head>
<body>
<center>
<h2> Parroquia San Ignacio de Loyola </h2>
<h3> Ficha Matrimonio </h3>
</center>

<form name="formulario8" method="post" action="conexion.php">
<center>
<table>


<tr>
<th align="left">Nombres del Novio:</th> <th><input type="text" name="nombreinstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos del Novio</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Celular</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Ocupación</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Nombres de la Novia</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Apellidos de la novia</th> <th><input type="text" name="apellidoinstructor" value=""></th>
</tr>
<tr>
<th align="left">Celular</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>
<tr>
<th align="left">Ocupación</th> <th><input type="text" name="cedulainstructor" value=""></th>
</tr>



<tr>
<th align="left"> Tiempo de conocidos </th>
<th > <input type="text" name="direinstructor" id="direinstructor" >
</tr>

<tr>
<th align="left"> Tiempo de noviazgo </th> 
<th>  <input type="text" name="correoinstructor" id="correoinstructor"> </th>                       
</tr>

<tr>
<th align="left" > Fecha de Matrimonio: </th> 
<th align="left" >  <input type="date" name="nacimientoinstructor" id="nacimientoinstructor" > 
</th>                       
</tr>
<tr>
<th align="left" > Fecha de curso prematrimonial: </th> 
<th align="left" >  <input type="date" name="nacimientoinstructor" id="nacimientoinstructor" > 
</th>                       
</tr>

          
</tr>
<tr>
<br>
<tr>
<tr>
<th><input type="submit" name="Aceptar" value="Aceptar"/> </th>
<th><input type="reset" name="Cancelar" value="Cancelar"/></th>
</tr>


</table>
</center>

</form> 

</body>
</html>
