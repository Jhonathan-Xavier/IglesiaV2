<?php

define('RUTA', 'http://localhost/login_curso/');

// nombre de base de datos
$bd_config = [
  'db_name' => 'login_curso',
  'user' => 'root',
  'pass' => ''
];


 ?>
